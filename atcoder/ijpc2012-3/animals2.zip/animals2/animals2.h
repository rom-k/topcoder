void construct(int N, int M, int E[][3]);
