void answer(long long C);
