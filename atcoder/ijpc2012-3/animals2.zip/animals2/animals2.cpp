#include "grader.h"
void construct(int N, int M, int E[][3]) {
  for(int i = 2; i <= N; i++) {
    answer(100000000000LL);
  }
}

