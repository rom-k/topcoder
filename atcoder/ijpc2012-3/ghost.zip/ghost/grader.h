void answer(double gx,double gy,double gz);
