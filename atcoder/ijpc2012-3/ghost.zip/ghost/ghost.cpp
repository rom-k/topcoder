#include "grader.h"
#include "ghost.h"
void FindGhost(int N,double Cx[],double Cy[],double Cz[],double Ty[],double Tz[])
{
answer(0.0,0.0,0.0);
}
