void FindGhost(int N,double Cx[],double Cy[],double Cz[],double Ty[],double Tz[]);
