int replace(int N, char S[]);
